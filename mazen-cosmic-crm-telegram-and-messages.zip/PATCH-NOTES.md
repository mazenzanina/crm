# Telegram auto + Messages v2 combined patch
- messages: 78 cards, shorter, no location, varied rituals
- types: telegram_* fields
- lib/telegram.ts: sender
- webhook: /api/telegram/webhook
- cron: /api/cron/telegram-daily (08:00 UTC = 09:00 Tunis)
- vercel.json: crons added
Deploy same way as messages: GitHub upload to same repo/branch/root then Vercel auto-deploys.
Need env: TELEGRAM_BOT_TOKEN, TELEGRAM_BOT_USERNAME, CRON_SECRET (or DAILY_CRON_SECRET), DAILY_LINK_SIGNING_KEY, SUPABASE_*

