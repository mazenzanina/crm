TAROT TN CRM — REPAIR 26 MISSING GITHUB FILES

Inspected public https://github.com/mazenzanina/crm at main commit 465134dc22a0427196ae361433e1cf1820682075.
All 28 files on GitHub match the tested manual-only CRM release. These 26 missing files prevent Vercel from building. No working files need replacing.

Use a local checkout of your EXISTING GitHub CRM repository, unzip this repair ZIP IN THE REPOSITORY ROOT (the folder containing package.json), preserving the src/ paths. Then commit these missing files and push to main. Do not upload this ZIP itself as one GitHub file. If you can only use a phone, GitHub's web upload can skip or flatten nested folders; a computer or GitHub Codespaces checkout is safer. No WhatsApp automation is included.

Verify on GitHub after pushing: src/lib/server.ts, src/lib/validation.ts, src/components/Signup.tsx, src/app/free-reading/page.tsx, src/app/icon.png. Vercel should then run npm ci + npm run build. This does not modify the website repository, Supabase client data or the LAUNCH10 paid-reading counter.

If the repository changes after commit 465134d, compare its latest file tree before applying this patch. Never share GitHub/Vercel/Supabase passwords or tokens.

FILES:
.env.example
.gitignore
src/app/api/auth-bridge/[...path]/route.ts
src/app/api/leads/route.ts
src/app/api/sky/route.ts
src/app/free-reading/page.tsx
src/app/globals.css
src/app/icon.png
src/app/layout.tsx
src/app/page.tsx
src/app/privacy/page.tsx
src/app/reset-password/page.tsx
src/components/AdminApp.tsx
src/components/ClientEditor.tsx
src/components/MoonDisc.tsx
src/components/Signup.tsx
src/lib/brandLogo.ts
src/lib/browser.ts
src/lib/dates.ts
src/lib/demo.ts
src/lib/messages.ts
src/lib/server.ts
src/lib/sky.ts
src/lib/types.ts
src/lib/useSky.ts
src/lib/validation.ts
